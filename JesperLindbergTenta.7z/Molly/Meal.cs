﻿namespace Molly
{
    class Meal
    {
        public List<Food> Foods { get; set; } = [];
        public DateTime Date { get; set; }
    }
}
